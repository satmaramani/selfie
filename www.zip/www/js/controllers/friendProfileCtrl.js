starterModule.controller('friendProfileCtrl', function($scope,$state,$rootScope,$timeout,$ionicHistory,commonService,friendProfileService,storageService,notificationService) {

    $scope.friendRequestSentBtn = true;
    $scope.isBlockedBtn         = true;
    $scope.accpetFriendRequestBtn = false;
    $scope.isFriendBtn = false;
    $scope.fromUserId=0;
    $scope.toUserId=0;
    $scope.btnText="Add Friend";
    $scope.profilePhotoBasePath=profilePhotoBasePath;
    try{
        var toUserId   = $state.params.selectedUser['_id'];
        var fromUserId = storageService.get('userId');
        var notificationDetail = $state.params.selectedUser['notificationDetail'];
    }
    catch(e){
    }
        
    if(fromUserId===undefined || fromUserId=="" || fromUserId==null){
        $ionicHistory.goBack();
    } 
    else if(notificationDetail===undefined){
        try{
            $scope.fromUserId = toUserId;
            $scope.toUserId   = fromUserId;
    
            friendProfileService.getOtherUserDetails({fromUserId:fromUserId, toUserId:toUserId}).then(function(resp){
                commonService.hideLoading();
                $scope.user = resp.data['user'];
                if($scope.user.profile_photo === ""){
                    $scope.user.profile_photo = 'img/noimage.png';
                } else{
                    $scope.user.profile_photo = resp.data['user']['profile_photo'];
                }
                if($scope.user.friend_ids!==undefined){
                    $scope.friendCount = $scope.user.friend_ids.length; 
                }
//                console.log(resp.data.requestStatus.request_status)
//                console.log(resp.data.requestStatus.from_user_id+" "+fromUserId);
                if(!resp.data.is_friend){
                    $scope.requestStatus = resp.data['requestStatus'].length; 
                    if(resp.data.requestStatus.from_user_id===fromUserId){
                        
                        if($scope.requestStatus===0){
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="pending"){
                            $scope.friendRequestSentBtn = true;
                            $scope.isBlockedBtn = $scope.accpetFriendRequestBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="accepted"){
                            $scope.isFriendBtn = true;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else{
                            // fromUserId blocked by toUserId
                            $scope.isBlockedBtn = $scope.friendRequestSentBtn = true;
                        }
                    }
                    else{
                    
                        if($scope.requestStatus===0){
                            $scope.isFriendBtn = $scope.friendRequestSentBtn = false;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="pending"){
                            $scope.accpetFriendRequestBtn = true;
                            $scope.isFriendBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="accepted"){
                            $scope.isFriendBtn = true;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else{
                            // fromUserId blocked by toUserId
                            $scope.friendRequestSentBtn = false;
                            $scope.isBlockedBtn         = true;
                        }
                    }
                    
                    
                }
                else{
                    $scope.isFriendBtn = true;
                    $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                }
                
                

            }, function(error){
                commonService.showAlert("Error", error);
            });
        }
        catch(e){
            alert(JSON.stringify(e));
        }
    }
    else{
        // We are here from notificationCtrl
        // You may got friend request, please accept / reject
         try{
            var parmas = {
                fromUserId  : notificationDetail.user_id,
                toUserId    : notificationDetail.sender_id
            };
          
            $scope.fromUserId = notificationDetail.user_id;
            $scope.toUserId   = notificationDetail.sender_id;
            
            friendProfileService.getOtherUserDetails(parmas).then(function(resp){
                commonService.hideLoading();
                $scope.user = resp.data['user'];
 
                if($scope.user.profile_photo === ""){
                    $scope.user.profile_photo = 'img/noimage.png';
                } else{
                    $scope.user.profile_photo = resp.data['user']['profile_photo'];
                }
                if($scope.user.friend_ids!==undefined){
                    $scope.friendCount = $scope.user.friend_ids.length; 
                }
                var reqStatusLen = resp.data['requestStatus'].length; 
                console.log(resp.data.requestStatus.from_user_id+" toUserId: "+$scope.fromUserId)
                if(!resp.data.is_friend){
                    if(resp.data.requestStatus.from_user_id===$scope.fromUserId){
                        
                        if(reqStatusLen===0){
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="pending"){
                            $scope.friendRequestSentBtn = true;
                            $scope.isBlockedBtn = $scope.accpetFriendRequestBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="accepted"){
                            $scope.isFriendBtn = true;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else{
                            // fromUserId blocked by toUserId
                            $scope.isBlockedBtn = $scope.friendRequestSentBtn = true;
                        }
                    }
                    else{
                    
                        if(reqStatusLen===0){
                            $scope.isFriendBtn = $scope.friendRequestSentBtn = false;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="pending"){
                            $scope.accpetFriendRequestBtn = true;
                            $scope.isFriendBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else if(resp.data.requestStatus.request_status==="accepted"){
                            $scope.isFriendBtn = true;
                            $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                        }
                        else{
                            // fromUserId blocked by toUserId
                            $scope.friendRequestSentBtn = false;
                            $scope.isBlockedBtn         = true;
                        }
                    }
                    
                                        
                }
                else{
                    $scope.isFriendBtn = true;
                    $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
                }
            }, function(error){
                commonService.showAlert("Error", error);
            });
            
            updateNotificationAsSeen([notificationDetail._id]);
            
        }
        catch(e){
            alert(JSON.stringify(e));
        }
        
    }
   
    // Send friend request
    $scope.sendFriendRequest = function(){
        // vice versa
        var user =JSON.parse(storageService.get('userDetails'));
          var params = {
                fromUserId  : $scope.toUserId,
                toUserId    : $scope.fromUserId,
                fromUserFullName:user.first_name+" "+user.last_name
        };
        
        friendProfileService.sendFriendRequest(params).then(function(resp){
            console.log(resp.data)
            if(resp.data.success){
                $scope.friendRequestSentBtn = true;
                $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.isFriendBtn = false;
            }
        }, function(error){
            commonService.showAlert("Error", error);
        });

    };

    // Accpet friend request
    $scope.acceptFriendRequest = function(){
        // vice versa
       var user =JSON.parse(storageService.get('userDetails'));
       
        var params = {
                fromUserId  : $scope.fromUserId,
                toUserId    : $scope.toUserId,
                fromUserFullName:user.first_name+" "+user.last_name
        };
        friendProfileService.acceptFriendRequest(params).then(function(resp){
            if(resp.data.success){
                $scope.isFriendBtn = true;
                $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
            }
        }, function(error){
            commonService.showAlert("Error", error);
        });

    };

    // Reject friend request
    $scope.rejectFriendRequest = function(){
        // vice versa
       var user =JSON.parse(storageService.get('userDetails'));
       
        var params = {
            fromUserId  : $scope.fromUserId,
            toUserId    : $scope.toUserId,
            fromUserFullName:user.first_name+" "+user.last_name
        };
//        console.log("Accpet req from >> ")
//       console.log($scope.fromUserId)
//       console.log(">> to user ")
//       console.log($scope.toUserId)
//       return
        friendProfileService.rejectFriendRequest(params).then(function(resp){
            if(resp.data.success){
                $scope.isFriendBtn = $scope.accpetFriendRequestBtn = $scope.friendRequestSentBtn = false;
                $scope.isBlockedBtn = true;
            }
        }, function(error){
            commonService.showAlert("Error", error);
        });
        
        updateNotificationAsSeen([notificationDetail._id]);
        
    };

    // Block friend request
    $scope.blockFriendRequest = function(){
        // vice versa
       var user =JSON.parse(storageService.get('userDetails'));
       
        var params = {
            fromUserId  : notificationDetail.type_id,
            toUserId    : notificationDetail.user_id,
            fromUserFullName:user.first_name+" "+user.last_name
        };

        friendProfileService.blockFriendRequest(params).then(function(resp){
            if(resp.data.success){
                $scope.isFriendBtn = true;
                $scope.accpetFriendRequestBtn = $scope.isBlockedBtn = $scope.friendRequestSentBtn = false;
            }
        }, function(error){
            commonService.showAlert("Error", error);
        });

    };

    function updateNotificationAsSeen(notificationIdsArr){
        
        notificationService.updateNotificationAsSeen({notificationIds:notificationIdsArr}).then(function(resp){
            if(resp.data.success){
                if($rootScope.newNotificationCnt)
                $rootScope.newNotificationCnt-=1;
            }
        },function(error){
            
        });
    }

});