starterModule.controller('homeCtrl', function($ionicScrollDelegate,$scope, $rootScope,$state,$timeout, postsService,commonService, homeService, userService, storageService, $ionicModal, friendProfileService,notificationService) {

	// ============ User Information
    var userId = storageService.get('userId');
    $scope.postPhotoBasePath=postPhotoBasePath;
    $scope.postPhotoBasePath=postPhotoBasePath;
    $scope.profilePhotoBasePath=profilePhotoBasePath;
    commonService.showLoading();
    userService.getUserDeatails({userId:userId}).success(function(res){
        commonService.hideLoading();
        
        $scope.profilePhotoBasePath = profilePhotoBasePath;

        
        // console.log(res.user.friend_ids);
        $scope.userObj = {"id":res.user['_id'], "first_name" : res.user['first_name'], "last_name" : res.user['last_name'], profile_photo : res.user['profile_photo']};
        storageService.set('userDetails',JSON.stringify(res.user));
        
        $scope.userFirstName = res.user['first_name'];
        $scope.friendIds = res.user.friend_ids;            
    })
    .error(function(){
        commonService.serverError();
    });

    $scope.curPage = 0;
    $scope.pageSize = 1;
    var limit = 10;
    
    $scope.followers = false;
    $scope.highlight = true;
    $scope.activehighlight = "active";
    $scope.activeFollowing = "";
    // ================== Get All Posts
    
    $scope.getNextPost = function(){
//         console.log($ionicScrollDelegate.getScrollPosition().top)
    };
    
    $scope.getAllPostsHome = function(getTabName){
       
        if(getTabName == "following"){
            $scope.activehighlight = "";
            $scope.activeFollowing = "active";
            $scope.highlight = false;
            $scope.followers = true;

            postsService.getFriendsPosts({loggedInUserId:userId,page:$scope.curPage, limit:limit}).then(function(resp){
            console.log(resp);
            $scope.allPostsData = resp.data['postPhotosData'];
            console.log($scope.allPostsData);

            // var friendIdsArr1 = [];
            // for (var i = 0; i < $scope.allPostsData.length; i++) {

            //     friendIdsArr1.push($scope.allPostsData[i].user_obj['id']);
            // };
            // var friendIdsArr2 = $scope.friendIds;        
            // $.each(friendIdsArr1, function(idx, value) {
            //     if($scope.allPostsData[idx].user_obj['id'] == userId){
            //         $scope.allPostsData[idx]['shareIcon'] = true;
            //     } else{
            //         $scope.allPostsData[idx]['shareIcon'] = false;
            //     }

            //     if ($.inArray(value, friendIdsArr2) == -1) {
                    
            //         if($scope.allPostsData[idx].user_obj['id'] == value && $scope.allPostsData[idx].user_obj['id'] !== userId){
            //             $scope.allPostsData[idx]['sendFriendReqIcon'] = true;
            //         } else{
            //             $scope.allPostsData[idx]['sendFriendReqIcon'] = false;
            //         }

                    
            //     } else {
                    
            //         if($scope.allPostsData[idx].user_obj['id'] == value){
            //             $scope.allPostsData[idx]['sendFriendReqIcon'] = false;
            //         } else{
            //             $scope.allPostsData[idx]['sendFriendReqIcon'] = true;
            //         }
            //     }
            // });
           
        }, function(error){
            commonService.showAlert("Error", error);
        });

        } else{
            $scope.activehighlight = "active";
            $scope.activeFollowing = "";
            $scope.highlight = true;
            $scope.followers = false;
            
            postsService.getAllPosts({loggedInUserId:userId,page:$scope.curPage, limit:limit}).then(function(resp){
            $scope.allPostsData = resp.data['postPhotosData'];
            console.log($scope.allPostsData);

            var friendIdsArr1 = [];
            for (var i = 0; i < $scope.allPostsData.length; i++) {

                friendIdsArr1.push($scope.allPostsData[i].user_obj['id']);
            };
            var friendIdsArr2 = $scope.friendIds;        
            $.each(friendIdsArr1, function(idx, value) {
                if($scope.allPostsData[idx].user_obj['id'] == userId){
                    $scope.allPostsData[idx]['shareIcon'] = true;
                } else{
                    $scope.allPostsData[idx]['shareIcon'] = false;
                }

                if ($.inArray(value, friendIdsArr2) == -1) {
                    
                    if($scope.allPostsData[idx].user_obj['id'] == value && $scope.allPostsData[idx].user_obj['id'] !== userId){
                        $scope.allPostsData[idx]['sendFriendReqIcon'] = true;
                    } else{
                        $scope.allPostsData[idx]['sendFriendReqIcon'] = false;
                    }

                    
                } else {
                    
                    if($scope.allPostsData[idx].user_obj['id'] == value){
                        $scope.allPostsData[idx]['sendFriendReqIcon'] = false;
                    } else{
                        $scope.allPostsData[idx]['sendFriendReqIcon'] = true;
                    }
                }
            });
           
        }, function(error){
            commonService.showAlert("Error", error);
        });
        }

        
    }
    
    // ======================== Send Friend Request
    $scope.sendFriendRequest = function(toUserId, fromUserFullName){
        var fromUserId = storageService.get('userId');
        var params = {fromUserId:fromUserId, toUserId:toUserId, fromUserFullName:fromUserFullName};
        friendProfileService.sendFriendRequest(params).then(function(resp){
            console.log(resp);
            // if(resp.data.success == true){
            //     $scope.expression = true;
            // } else{
            //     $scope.expression = true;
            // }

        }, function(error){
            commonService.showAlert("Error", error)
        });        
    }

    // ======================

    $scope.nextPage = function(curPage){
        postsService.getAllPosts({loggedInUserId:userId,page:curPage, limit:limit}).then(function(resp){
            $scope.allPostsData = resp.data['postPhotosData'];
            console.log($scope.allPostsData);
        }, function(error){
            commonService.showAlert("Error", error);
        });
    }

    $scope.prevPage = function(curPage){
        postsService.getAllPosts({loggedInUserId:userId,page:curPage, limit:limit}).then(function(resp){
            $scope.allPostsData = resp.data['postPhotosData'];
            console.log($scope.allPostsData);
        }, function(error){
            commonService.showAlert("Error", error);
        });
    }

    // ================== Like Photo
      $scope.likePostPhoto = function (photoId, likeImage, userObj, i) {
        homeService.likePostPhoto({userObj:JSON.stringify(userObj), photoId:photoId}).then(function(resp){
            $scope.allPostsData[i]['likes_count'] = resp.data.postDetails['likes_count']; 
                if(resp.data.success){
                    $scope.allPostsData[i]['is_liked'] = resp.data.success;
                }

            }, function(error){
            commonService.showAlert("Error", error);
        });
    };

    // =============== Unlike Photo
    $scope.unlikePostPhoto = function (photoId, unlikeImage, userObj, i) {
        homeService.unlikePostPhoto({userObj:JSON.stringify(userObj), photoId:photoId}).then(function(resp){
                $scope.allPostsData[i]['likes_count'] = resp.data.postDetails['likes_count']; 
                if(resp.data.success){
                    $scope.allPostsData[i]['is_liked'] = !resp.data.success;
                }
            }, function(error){
            commonService.showAlert("Error", error);
        });
    };

    // =========================== Option Modal

    $scope.other_option_popup = false;
    $scope.option_popup = false;
    $ionicModal.fromTemplateUrl('templates/optionPopup.html', {
        scope: $scope
    }).then(function (option) {
        $scope.option = option;
    });
    $scope.photoId=0;

    $scope.openOption = function (photoId, index) {
        // alert(index);
        $scope.index   = index;
        $scope.photoId = photoId;
        $scope.other_option_popup = false;
        $scope.option_popup = true;
        $scope.option.show();

        var countUp = function() {
            $scope.other_option_popup = false;
            $scope.option_popup = false;
            $scope.option.hide();
        }

        $timeout(countUp, 3000);
    };


    $scope.editPhoto = function(){
        console.log('editPhoto' + $scope.photoId);
        // homeService.editPhoto({photoId:$scope.photoId}).then(function(resp){
  //           console.log(resp);
                
  //           }, function(error){
  //           commonService.showAlert("Error", error);
  //       })
    };

    // =================== Delete Photo
    $scope.deletePhoto = function(){
        homeService.deletePhoto({photoId:$scope.photoId}).then(function(resp){
            if(resp.data.success == true){
                $scope.getAllPostsHome();
            } else{
                commonService.showAlert("Error", "Something went wrong please try again.");    
            }

            }, function(error){
            commonService.showAlert("Error", error);
        })
    }

    $scope.goCommentsPage = function(postId){
        var commentParams={
            postId  : postId
        };
       
        $state.go('app.comments', {commentParams:commentParams});
    };    
    
    
    $rootScope.newNotificationCnt=0;
     
//  Get fresh notification
    if(userId){
        setInterval(function(){

            notificationService.getFreshNotification(userId).then(function(resp){
                $rootScope.newNotificationCnt=resp.data.notificationCount;
            }, function(){
//                console.log("serverError");
            });

        }, 5000);
    }
		
    $scope.getAllPostsHome();
});
