starterModule.factory('commentsService', ['$http',function($http){
      
    var root = {};
   
    root.getAllComments = function(params){
        return   $http.get(baseUrl+"postComments/"+params.postId +"/"+ params.page +"/"+ params.limit);
    };

    root.postComments = function(params){
        return   $http.post(baseUrl+"postComments",params);
    };

    root.updateComment = function(params){
        return   $http.put(baseUrl+"postComments",params);
    };

    root.deleteComment = function(params){
        return   $http.delete(baseUrl+"postComments/"+params.postId+"/"+params.postCommentId);
    };
    
    return root;
}]);