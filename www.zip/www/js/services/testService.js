starterModule.factory('testService', ['$http',function($http){
      
    var root = {};
   
    root.test = function(params){
        var conf = {
         method : 'post',
         url    : baseUrl+"authenticate",
         params : params
        };
        return $http(conf);
    };
   
    return root;
}]);