starterModule.factory('homeService', ['$http',function($http){
      
    var root = {};
   
    root._USER = {};
    
    root.likePostPhoto = function(params){
    	return   $http.post(baseUrl+"likePostPhoto", params);
    };

    root.unlikePostPhoto = function(params){
        return   $http.put(baseUrl+"likePostPhoto", params);
    };

    root.editPhoto = function(params){
        return   $http.put(baseUrl+"posts", params);
    };

    root.deletePhoto = function(params){
        return   $http.delete(baseUrl+"posts/"+ params.photoId);
    };

    return root;
}]);