angular.module('starter', ['ionic', 'starter.controllers', 'ngMessages', 'ion-floating-menu'])
        .run(function($ionicPlatform, $rootScope, $location, $ionicScrollDelegate) {
            $rootScope.$on('$stateChangeStart', function(event, toState, $scope, $state, $urlRouterProvider, $location) {

                $rootScope.myfooter = true;
                $rootScope.competitionHeader    = false;
                $rootScope.HomeHeader           = false;
                $rootScope.editProfileHeader    = false;
                $rootScope.notificationHeader   = false;
                $rootScope.profileHeader        = false;
                $rootScope.settingHeader        = false;
                $rootScope.folderHeader         = false;
                $rootScope.imageHeader          = false;
                $rootScope.friendHeader         = false;
                $rootScope.honorHeader          = false;
                $rootScope.friendProfileHeader  = false;
                $rootScope.friendSearchResult   = false;
                $rootScope.commentsHeader       = false;
                $rootScope.addFolderHeader      = false;
                $rootScope.pageProfileHeader    = false;
                $rootScope.editPageProfileHeader= false;
                $rootScope.postGalleryHeader    = false;
                $rootScope.postPhotosHeader     = false;
                $(".competitionfooter").removeClass('activeHeader');
                $(".notificationfooter").removeClass('activeHeader');
                $(".profilefooter").removeClass('activeHeader');
                $(".homefooter").removeClass('activeHeader');
                
                if((toState.name == "app.signIn") || (toState.name == "app.comments") || (toState.name == "app.signIn1") || (toState.name == "app.signIn2") || (toState.name == "app.signIn3")){
                    $rootScope.myfooter = false;
                }
                else if(toState.name == "app.home"){
                    setTimeout(function() {
                        $ionicScrollDelegate.scrollTop(true);
                    }, 10);
                    $rootScope.HomeHeader = true;
                    $(".homefooter").addClass('activeHeader');
                }
                else if(toState.name == "app.competion"){
                    $rootScope.competitionHeader = true;
                    $(".competitionfooter").addClass('activeHeader');
                }
                else if(toState.name == "app.notification"){
                    $rootScope.notificationHeader = true;
                    $(".notificationfooter").addClass("activeHeader");
                }
                else if(toState.name == "app.profile"){
                    $rootScope.profileHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.setting"){
                    $rootScope.settingHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.editprofile"){
                    $rootScope.editProfileHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.folder"){
                    $rootScope.folderHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.imageDetail"){
                    $rootScope.imageHeader = true;
                }
                else if(toState.name == "app.friend"){
                    $rootScope.friendHeader = true;
                }
                else if(toState.name == "app.honors"){
                    $rootScope.honorHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.comments"){
                    $rootScope.commentsHeader = true;
                    $(".homefooter").addClass('activeHeader');
                }
                else if(toState.name == "app.addFolder"){
                    $rootScope.addFolderHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.page"){
                    $rootScope.pageProfileHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.editPageProfile"){
                    $rootScope.editPageProfileHeader = true;
                    $(".profilefooter").addClass("activeHeader");
                }

                else if(toState.name == "app.friendProfile"){
                    $rootScope.friendProfileHeader = true;
                }
                else if(toState.name == "app.friendSearchResult"){
                    $rootScope.friendSearchResult = true;
                    $(".profilefooter").addClass("activeHeader");
                }
                else if(toState.name == "app.postGallery"){
                    $rootScope.postGalleryHeader = true;
                    $rootScope.myfooter = false;
                }
                else if(toState.name == "app.postPhotos"){
                    $rootScope.postPhotosHeader   = true;
                }
            });
        })

        .config(function($stateProvider, $urlRouterProvider,$httpProvider) {
            $httpProvider.interceptors.push('selfieInterceptor');
            $stateProvider
                    .state('app', {
                        url: "/app",
                        abstract: true,
                        templateUrl: "templates/menu.html",
                        controller: 'AppCtrl'
                    })
                    .state('app.test', {
                        url: "/test",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/test.html",
                                controller: 'testCtrl'
                            }
                        }
                    })
                    .state('app.home', {
                        url: "/home",
                        cache:false,
                        views: {
                            'menuContent': {
                                templateUrl: "templates/home.html",
                                controller: 'homeCtrl'
                            }
                        }
                    })

                    .state('app.signIn', {
                        url: "/signIn",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/signIn.html",
                                controller: 'signIn'
                            }
                        }
                    })

                    .state('app.signIn1', {
                        url: "/signIn1",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/signIn1.html",
                                controller: 'signIn'
                            }
                        }
                    })

                    .state('app.signIn2', {
                        url: "/signIn2",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/signIn2.html",
                                controller: 'signIn'
                            }
                        }
                    })

                    .state('app.signIn3', {
                        url: "/signIn3",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/signIn3.html",
                                controller: 'signIn'
                            }
                        }
                    })

                    .state('app.competion', {
                        url: "/competion",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/competion.html",
                                controller: 'competion',
                            }
                        }
                    })

                    .state('app.notification', {
                        url: "/notification",
                        cache:false,
                        views: {
                            'menuContent': {
                                templateUrl: "templates/notification.html",
                                controller: 'notificationCtrl'
                            }
                        }
                    })

                    .state('app.profile', {
                        url: "/profile",
                        cache:false,
                        views: {
                            'menuContent': {
                                templateUrl: "templates/profile.html",
                                controller: 'userProfile'
                            }
                        }
                    })

                    .state('app.editprofile', {
                        url: "/editprofile",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/editProfile.html",
                                controller: 'userProfile'
                            }
                        }
                    })

                    .state('app.setting', {
                        url: "/setting",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/setting.html",
                                controller: 'setting',
                            }
                        }
                    })

                    .state('app.folder', {
                        url: "/folder",
                        params:{
                                selectedCat     :null,
                                selectedCatName :null
                        },
                        views: {
                            'menuContent': {
                                templateUrl: "templates/folder.html",
                                controller: 'folder',
                            }
                        }
                    })


                    .state('app.imageDetail', {
                        url: "/imageDetail",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/imageDetail.html",
                                controller: 'folder',
                            }
                        }
                    })

                    .state('app.friend', {
                        url: "/friend",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/friend.html",
                                controller: 'friend',
                            }
                        }
                    })

                    .state('app.honors', {
                        url: "/honors",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/honors.html",
                                controller: 'honors'
                            }
                        }
                    })
                    .state('app.comments', {
                        url: "/comments",
                        params:{
                                commentParams     :null
                        },
                        views: {
                            'menuContent': {
                                templateUrl: "templates/comments.html",
                                controller: 'comments'
                            }
                        }
                    })

                    .state('app.addFolder', {
                        url: "/addFolder",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/addFolder.html",
                                controller: 'folder'
                            }
                        }
                    })

                    .state('app.page', {
                        url: "/page",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/page.html",
                                controller: 'page'
                            }
                        }
                    })

                    .state('app.editPageProfile', {
                        url: "/editPageProfile",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/editPageProfile.html",
                                controller: 'page'
                            }
                        }
                    })

                .state('app.setup', {
                        url: "/setup",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/setup.html",
                                controller: 'setupCtrl'
                            }
                        }
                    })

                .state('app.friendProfile', {
                    url: "/friendProfile",
                    cache:false,
                    params: {
                        selectedUser: null
                      },
                    views: {
                        'menuContent': {
                            templateUrl: "templates/friendProfile.html",
                            controller: 'friendProfileCtrl'
                        }
                    }
                })

                .state('app.friendSearchResult', {
                        url: "/friendSearchResult",
                        cache:false,
                        params: {
                            searchForUser: null
                          },
                        views: {
                            'menuContent': {
                                templateUrl: "templates/friendSearchResult.html",
                                controller: 'friendSearchResultCtrl'
                            }
                        }
                    })

                .state('app.postGallery', {
                        url: "/postGallery",
                        views: {
                            'menuContent': {
                                templateUrl: "templates/postGallery.html",
                                controller: 'postGalleryCtrl'
                            }
                        }
                    })

                    
                .state('app.api', {
                    url: "/api",
                    views: {
                        'menuContent': {
                            templateUrl: "templates/api.html",
                            controller: 'apiCtrl'
                        }
                    }
                })


                .state('app.postPhotos', {
                        url: "/postPhotos",
                        cache:false,
                        params:{
                           postPhotosDetail: null
                        },
                        views: {
                            'menuContent': {
                                templateUrl: "templates/postPhotos.html",
                                controller: 'postPhotosCtrl'
                            }
                        }
                    })            

            $urlRouterProvider.otherwise('/app/setup');
        });
