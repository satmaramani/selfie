starterModule.controller('apiCtrl', function($scope, $rootScope,$state,$timeout,userService,storageService,authService,commonService,apiService) {
    $rootScope.myfooter = false;
    $scope.reset = function(){
        $("#jsonObj").val('');
        $scope.response="";
        
        
    $scope.requestType=[
        { id:1,reqName:"Get" },
        { id:2,reqName:"Post" },
        { id:3,reqName:"Put" },
        { id:4,reqName:"Delete" }
    ];

    $scope.selectedRequestType=1;
    
    };
    $scope.reset();
    
    $scope.getResult = function(){
        try{
            $scope.response="";
            var selectedReqId=$("#selectedReqId").val();
            var reqUrl=$("#reqUrl").val();
            
            var params={};
            
            if(selectedReqId==2 || selectedReqId==3){
                params=JSON.parse($("#jsonObj").val());
                params.userObj=JSON.stringify(params.userObj);
            }
            params.selectedReqId=selectedReqId;
            params.reqUrl=reqUrl;
            
            console.log(selectedReqId);
            console.log(params);
            
            if(selectedReqId==1){ 
                apiService.getData(params).then(function(res){
                    console.log(res.data);
                    $scope.response=res.data;
                });
            }
            else if(selectedReqId==2){
                apiService.postData(params).then(function(res){
                    console.log(res.data);
                    $scope.response=res.data;
                });
            }
            else if(selectedReqId==3){
                apiService.putData(params).then(function(res){
                    console.log(res.data);
                    $scope.response=res.data;
                });
            }
            else if(selectedReqId==4){
                apiService.deleteData(params).then(function(res){
                    console.log(res.data);
                    $scope.response=res.data;
                });
            }
//                

        }
        catch(e){
                console.log(e);
            commonService.showAlert("Error","Invalid JSON");
        }
    
    };
    
});