starterModule.factory('postsService', ['$http',function($http){
      
    var root = {};
   
    root.postPhoto = function(params){
        return   $http.post(baseUrl+"posts", params);
    };

    root.uploadPhotoPost = function(params){
        return   $http.post(baseUrl+"uploadPhotoPost",params);
    };
    
    root.getAllPosts = function(params){
        return   $http.get(baseUrl+"posts/"+params.loggedInUserId+ "/"+ params.page + "/" + params.limit);
    };

    root.getFriendsPosts = function(params){
        return   $http.get(baseUrl+"posts/getFriendsPosts/"+params.loggedInUserId+ "/"+ params.page + "/" + params.limit);
    };

    root.getPostPhotosDetail = function(postId){
        return   $http.get(baseUrl+"posts/"+postId);
    };

    
    return root;
}]);