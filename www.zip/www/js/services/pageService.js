starterModule.factory('pageService', ['$http',function($http){
      
    var root = {};
    
    root.getAllPageDetails = function(params){
        return   $http.get(baseUrl+"page");
    };

    root.createNewPage = function(params){
        return   $http.post(baseUrl+"page", params);
    };
   
    root.updatePageInfo = function(params){
        return   $http.put(baseUrl+"page", params);
    };
    
    
    return root;
}]);