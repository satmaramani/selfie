starterModule.controller('friend', function($scope, storageService, friendService) {
    $scope.followers = false;
    $scope.highlight = true;
    $scope.activehighlight = "active";
    $scope.activeFollowing = "";

    $scope.myGoBack = function() {
        window.history.back();
    };

    $scope.profilePhotoBasePath = profilePhotoBasePath;

    $scope.getFriendDeatails = function(){

        var loginUserInfo = JSON.parse(storageService.get('userDetails'));
            var params = {"friendIds":loginUserInfo.friend_ids};
            
            friendService.getFriendDeatails(params).success(function(res){
                console.log(res.friendsData);
                $scope.friendsData = res.friendsData;
        }) 
        .error(function(){
            commonService.serverError();
        });
    }

    $scope.getAllFriends = function(value) {
        console.log(value);
        if(value == 'highlights'){

            $scope.activehighlight = "active";
            $scope.activeFollowing = "";
            $scope.highlight = true;
            $scope.followers = false;

            $scope.getFriendDeatails();

        } else if(value == 'following'){
            $scope.activehighlight = "";
            $scope.activeFollowing = "active";
            $scope.highlight = false;
            $scope.followers = true;
            
        } else{
            $scope.activehighlight = "active";
            $scope.activeFollowing = "";
            $scope.highlight = true;
            $scope.followers = false;
        }
    }

    $scope.getFriendDeatails();
});