starterModule.controller('setting', function($scope,$state,$rootScope,storageService) {
    $scope.myGoBack = function() {
        window.history.back();
    };
    $rootScope.logout = function(){
        storageService.set("token","");
        storageService.set("userId","");
        storageService.set("userDetails","");
        $rootScope.settingHeader = $rootScope.myfooter = false;
        $state.go('app.signIn');
    };
    
   
});