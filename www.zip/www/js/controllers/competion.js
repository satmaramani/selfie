starterModule.controller('competion', function ($scope) {
    
})


