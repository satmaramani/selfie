starterModule.controller('signIn', function($scope, $rootScope, $ionicScrollDelegate, $ionicModal,
                                            $ionicHistory, $location, $window,$state,
                                            $ionicSlideBoxDelegate, userService,storageService,Upload) {
    var newUser = {};
    
    $scope.user = {
        email : "", 
        pass : ""
    };

    $scope.register = {
        email : "", 
        pass : "",
        first_name : "",
        last_name : "",
        gender : "M",
        profile_photo : ""
    };

    $ionicModal.fromTemplateUrl('templates/signInPopup.html', {
        scope: $scope
    }).then(function (modal) {
        $scope.linkpage = true;
        $scope.modal = modal;
    });

    $ionicModal.fromTemplateUrl('templates/joinPopup.html', {
        scope: $scope
    }).then(function (join) {
        $scope.join = join;
    });

    $ionicModal.fromTemplateUrl('templates/profilePopup.html', {
        scope: $scope
    }).then(function (profile) {
        $scope.profile = profile;
    });


    

    function profilePopup() {
         userService.signIn({ email : $scope.register.email, password :  $scope.register.pass}).then(
                function(res){
                        if(res.data.success){
                            //save token to localstorage
                            storageService.set('token',res.data.token);
                            $ionicScrollDelegate.scrollTop();
                            $scope.join.hide();
                            $scope.profile.show();
                        }
                }
        );
        
    }

   $scope.aboutPopup = function () {
        $scope.about_popup = true;
        $ionicScrollDelegate.scrollTop();
        $scope.modal.show();
    };

    $scope.closeAboutPopup = function () {
        $scope.modal.hide();
    };

    $scope.signIn = function(){
        $scope.errMsg = "";
        if($scope.user.email === "" || $scope.user.pass === ""){
            $scope.errMsg = "Enter email and password";
        }else{
            //make server call   
            userService.signIn({ email : $scope.user.email, password :  $scope.user.pass}).then(
                function(res){

                        if(res.data.success){
                            //save token to localstorage
                            storageService.set('token',res.data.token);
                            storageService.set('userId',res.data.userId);
                            $scope.closeAboutPopup();
                            $rootScope.$emit('refresh',null);
                            $location.path('#/app/setup');
                        }else{
                            $scope.errMsg = "Sign In Failed.";
                        }
                },
                function(err){
                        $scope.errMsg = "Unable to sign-in now.";
                }
            );
        }
    };


    $scope.joinPopup = function () {
        $ionicScrollDelegate.scrollTop();
        $scope.join.show();
    };

    $scope.registerUser = function(){
        $scope.registerErrMsg = "";
        if($scope.register.email === "" || $scope.register.pass === ""){
            $scope.registerErrMsg = "Enter email and password";
        }else{
            //make server call   
            userService.signUp({ email_id : $scope.register.email, password :  $scope.register.pass}).then(
                function(res){
                        if(res.data.success){
                            newUser = res.data.user;
                            profilePopup();
                        }else{
                            $scope.registerErrMsg = "Sign up Failed.";
                        }
                },
                function(err){
                        $scope.registerErrMsg = "Unable to sign-up now.";
                }
            );
        }
    };

    $scope.profile = { uploadme : ""};
    function saveUserProfileImage(){
        //check if from is valid
        if ($scope.profile.uploadme) { 
                Upload.upload({
                url: baseUrl+'uploadProfileImage', //webAPI exposed to upload the file
                data:{file:$scope.profile.uploadme} //pass file as data, should be user ng-model
            }).then(function (resp) { //upload function returns a promise
                
                if(resp.data.success){ //validate success
                    $scope.register.profile_photo = resp.data.image;
                    console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ');
                } 
                uploadUserInfo();
            }, function (resp) { //catch error
                uploadUserInfo();
            }, function (evt) { 
                console.log(evt);
            });
        }else{
           uploadUserInfo();
        }
    }

    function uploadUserInfo(){
        $scope.profileErrMsg = "";
        if($scope.register.first_name === "" || $scope.register.last_name === ""){
            $scope.profileErrMsg = "Enter first and last name";
        }else{
            var token = storageService.get('token');
            var params = {gender : $scope.register.gender, 
                            user_id : newUser._id,
                            first_name: $scope.register.first_name,
                            last_name :$scope.register.last_name,
                            profile_photo : $scope.register.profile_photo,
                            token : token};

            userService.update(params).then(
                function(res){
                        if(res.data.success){
                            $scope.profile.hide();
                            $rootScope.$emit('refresh',null);
                            $location.path('#/app/setup');
                        }else{
                            $scope.profileErrMsg = "Update failed.";
                        }
                },
                function(err){
                        $scope.profileErrMsg = "Unable to update information now.";
                }
            );
        }
    }

    $scope.updateUser = function(){
        saveUserProfileImage();
    };


})