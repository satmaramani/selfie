starterModule.controller('folder', function ($scope, $window, $rootScope,$state,$timeout,$ionicPopup,commonService,userService,storageService,categoryService,Upload) {

    $scope.categoryName = $state.params.selectedCatName;
    console.log($scope.categoryName);
    
    var userId = storageService.get('userId');

    if($state.params.selectedCat === null || $state.params.selectedCat === undefined){
        $scope.myGoBack();
    }
    try{
        var userDetails         = JSON.parse(storageService.get('userDetails'));
        $scope.selectedCatName  = userDetails.categories[$state.params.selectedCat];
    }
    catch(e){ // Category not found
        $scope.myGoBack();
    }
    var dev_height = $window.innerHeight;
        dev_height = dev_height - 150;
        
   // set height for ion-content     
    var deviceHeight = function(){
        $(".slidercard").css("height", dev_height);
    };
    deviceHeight();
    $scope.category={imgObj:""};
    $scope.showSliderDiv=true;
    $scope.showCameraDiv=false;
    $scope.photoPath="";
    
    // Get photo from gallery
    $scope.getPhotoFromGallery = function(){
        $scope.category.imgObj="";
        $scope.showSliderDiv=false;
        $scope.showCameraDiv=false;
    };
    
    // Get photo from camera
    $scope.getPhotoFromCamera = function(){
        alert("getPhotoFromCamera");
        $scope.category.imgObj="";
        $scope.showSliderDiv=false;
        $scope.showCameraDiv=true;        
    };
    // show category slider
    $scope.resetSlider = function(){
        $scope.category.imgObj="";
        $scope.photoPath="";
        $scope.showSliderDiv=true;
        $scope.showCameraDiv=false;
    };
    
//    Insert record in category photo schema
    function addPhotoInCat(params){
        categoryService.addPhotoInCat(params).then(function(resp){
            if(resp.data.success){
                $scope.category.imgObj="";
            }
            else{
                commonService.showAlert("Uploading Failed","Please try later");
            }
            console.log(resp)
        },function(error){
            commonService.showAlert("Failded to add photo","Please try later");
        });
        
    }
 
    // Upload photo in category
    $scope.uploadPhotoInCategory = function(){
        
        if(!$scope.category.imgObj){
            return commonService.showAlert("Choose Photo","Choose photo from camera or gallery to upload");
        }
        else{

            Upload.upload({
                url: baseUrl + 'uploadPhotoInCategory',
                data: {file: $scope.category.imgObj}
            }).then(function (resp) {

                    if(resp.data.success){
                        var params = {"image": resp.data.image, "userId" : userId, "catId": $state.params.selectedCat};
                        addPhotoInCat(params);
                    }
                    else{
                        commonService.showAlert("Failded to upload", "Please try later");
                    }

            }, function (error) { //catch error
                commonService.serverError();
            });
        }
        
    };
    
    // Fetch selected category images
    var getCategoryImages = function(){
        
        var params = {"userId" : userId, "catId": $state.params.selectedCat};
        categoryService.getCategoryImages(params).then(function(resp){
            if(resp.data.success){
                $scope.catImageData = resp.data.catImgData;
                $scope.imageBaseUrl = categoryImageBasePath;
            }
            else{
                console.log("No images found inside # "+ $state.params.selectedCat + " category.");
            }
        }, function(error){
            commonService.serverError();
        });
        
    };
    
    $scope.deleteCategory = function(){
        var userDetails = JSON.parse(storageService.get('userDetails'));
        var deleteCategoryPopup = $ionicPopup.confirm({
            title:      "Delete "+$scope.selectedCatName+ " ?" ,
            subTitle:   "All photo's will be deleted !",
            template:   "Are you sure want to delete ?"
        });

        deleteCategoryPopup.then(function (res){
            if (res) {
                delete userDetails.categories[$state.params.selectedCat];
                userDetails.categories   = JSON.stringify(userDetails.categories);
                userDetails.user_id      = userDetails._id;
                updateUser(userDetails);
            }
        });

    };
    
    // Update user when category delete
    
    function updateUser(params){
        commonService.showLoading();
        userService.setUserDetails(params).then(function(resp){
            commonService.hideLoading();
            if(resp.data.success){
                console.log("categories updated, now delete photos inside the category");
                deleteCategory({userId:params._id,catId:$state.params.selectedCat});
            }else{
                commonService.showAlert("Failed","Unable to delete category");
            }
        },
        function(error){
            commonService.serverError();
        }
        );
    }
    
    // Delete category photos
    function deleteCategory(parmas){
        categoryService.deleteCategory(parmas).then(function(resp){
            commonService.hideLoading();
            if(resp.data.success){
                $scope.myGoBack();
            }else{
                commonService.showAlert("Failed","Unable to delete category");
            }
        },
        function(error){
            commonService.serverError();
        }
        );
    }
    
    // Fetch images of selected category
    getCategoryImages();
    

});


