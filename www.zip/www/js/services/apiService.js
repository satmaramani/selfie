starterModule.factory('apiService', ['$http',function($http){
      
    var root = {};
    
    root.getData = function(params){
        return $http.get(params.reqUrl);
    };
    root.postData = function(params){
        return $http.post(params.reqUrl,params);
    };
    root.putData = function(params){
        return $http.put(params.reqUrl,params);
    };
    root.deleteData = function(params){
        return $http.delete(params.reqUrl);
    };

    return root;
}]);