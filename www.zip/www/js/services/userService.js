starterModule.factory('userService', ['$http',function($http){
      
    var root = {};
   
    root._USER = {};

    root.signIn = function(params){
        return $http.post(baseUrl+"authenticate", params);
    };

    root.signUp = function(params){
        return $http.post(baseUrl+"users", params);
    };

    root.update = function(params){
        return $http.put(baseUrl+"users", params);
    };
   
    root.getUserDeatails = function(params){
        return $http.get(baseUrl+"users/"+params.userId);
    };
   
    root.setUserDetails = function(params){
        return $http.put(baseUrl+"users",params);
    };
   
    root.findByNameAndLocaion = function(params){
        return   $http.get(baseUrl+"users/findByNameAndLocaion/"+params.name+"/"+params.location+"/"+params.userId);
    };
    
    root.forgotPwd = function(params){
        return   $http.post(baseUrl+"users/forgotPwd", params);
    };
    
    return root;
}]);