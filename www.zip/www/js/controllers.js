var starterModule = angular.module('starter.controllers', ['google.places', 'ngFileUpload'])
starterModule.controller('AppCtrl', function ($scope, $ionicScrollDelegate, $ionicModal, $ionicHistory, $location, $window, $ionicSlideBoxDelegate, $ionicPopover,$state,commonService,userService,storageService, homeService, postsService) {
    $(".homefooter").addClass('activeHeader');
    
    $scope.user={name:"",location:""};
    
    $ionicModal.fromTemplateUrl('templates/signInPopup.html', {
        scope: $scope
    }).then(function (modal) {
        $scope.linkpage = true;
        $scope.modal = modal;
    });

    $scope.aboutPopup = function () {
        $scope.about_popup = true;
        $ionicScrollDelegate.scrollTop();
        $scope.modal.show();
    };

    $scope.closeAboutPopup = function () {
        $scope.modal.hide();
    };


    $ionicModal.fromTemplateUrl('templates/forgotPwdPopup.html', {
        scope: $scope
    }).then(function (modal1) {
        $scope.modal1 = modal1;
    });

    $scope.forgotPwdPopup = function () {
        $scope.about_popup = false;
        $scope.forgot_popup = true;
        $ionicScrollDelegate.scrollTop();
        $scope.modal1.show();        
    };

    // ================ Forgot Password
    $scope.forgotPwd = function(userEmailId){
        userService.forgotPwd({emailId:userEmailId}).then(function(res){
            console.log(res.data['success']);
            if(res.data['success'] == true){
                commonService.showAlert("Success", "Email sent successfully.");
            }
        }, function(error){
            commonService.showAlert("Error", error);
        });
    }

    $ionicModal.fromTemplateUrl('templates/joinPopup.html', {
        scope: $scope
    }).then(function (join) {
        $scope.join = join;
    });
    $scope.joinPopup = function () {
        $scope.join_popup1 = false;
        $scope.join_popup = true;
        $ionicScrollDelegate.scrollTop();
        $scope.join.show();
    };

    $ionicModal.fromTemplateUrl('templates/joinPopup1.html', {
        scope: $scope
    }).then(function (join1) {
        $scope.join1 = join1;
    });
    $scope.joinPopup1 = function () {
        $scope.join_popup1 = true;
        $scope.join_popup = false;
        $ionicScrollDelegate.scrollTop();
        $scope.join1.show();
    };

//    Last registration popup
    $ionicModal.fromTemplateUrl('templates/joinPopup.html', {
        scope: $scope
    }).then(function (gallery) {
        $scope.gallery = gallery;
    });
    $scope.openGallery = function () {
        $scope.gallery_popup = true;
        $scope.join_popup1 = true;
        $ionicScrollDelegate.scrollTop();
        $scope.gallery.show();
    };

    $scope.goBack = function () {
        $scope.modal1.hide();
        $scope.about_popup = true;
        $scope.forgot_popup = false;
    };

    $scope.myGoBack = function () {  
        window.history.back();
    };

    $scope.hideDone = function () {
        $scope.join_popup1 = false;
        $(".modal-backdrop").removeClass('active');
        $location.path("/app/home");
        $window.location.reload(true)
    };


//    $scope.images = [];
//    $scope.loadImages = function () {
//        for (var i = 0; i < 5; i++) {
//            $scope.images.push({id: i, src: "img/bg2.jpg"});
//        }
//    }
//    $scope.loadImages();

    $ionicPopover.fromTemplateUrl("menuPopover.html", {
        scope: $scope
    }).then(function (popover) {
        $scope.menuPopover = popover;
    });

    $scope.openMenuPopover = function ($event) {
        $scope.menuPopover.show($event);
    };

    $ionicModal.fromTemplateUrl('templates/sharePopup.html', {
        scope: $scope
    }).then(function (share) {
        $scope.share = share;
    });
    $scope.sharePopup = function () {
        $scope.share_popup = true;
        $ionicScrollDelegate.scrollTop();
        $scope.share.show();
    };
    
    $scope.searchUser=function(){
        $scope.user.name=$scope.user.name.trim();
        if($scope.user.name===""){
            commonService.showAlert("Validation Error","Please Enter Name");
            return;
        }
        $scope.menuPopover.hide();
        $state.go("app.friendSearchResult",{searchForUser:$scope.user});
    };
    
//    $scope.goToUrl=function(url){
//        $state.go("app."+url);
//    };
    

});