starterModule.controller('comments', function ($scope, $ionicHistory,$state, commentsService, storageService, commonService) {
    $("#comment").focus();
    
    $scope.userComment = {comment : ''};
    var postId = $state.params.commentParams['postId'];
    var loginUserInfo = JSON.parse(storageService.get('userDetails'));
    $scope.userId = loginUserInfo._id;
    $scope.updateBtn = false;
    $scope.sendBtn = true;

    var page = 0;
    var limit = 5;

    $scope.getAllComments = function(){
        var params = {postId:postId, page : page, limit : limit};
        commentsService.getAllComments(params).then(function(resp){
            
            if(resp.data.postCommentsData.length > 0){
                $scope.allCommentsData = resp.data.postCommentsData;
            } else{
                return false;
            }

        }, function(error){
            commonService.showAlert("Error", error)
        });

    }

    $scope.sendComment = function(){
        
        var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
        var comment = $scope.userComment['comment'];
        
        var params = {postId:postId, userObj:JSON.stringify(userObj), comment : comment};
        commentsService.postComments(params).then(function(resp){
            $scope.userComment.comment = "";
            $scope.getAllComments();

        }, function(error){
            commonService.showAlert("Error", error)
        });
    }

    $scope.editComment = function(comment, commentId, index){
        $scope.index = index;
        $scope.commentId = commentId;
        $scope.userComment = {comment : comment};
        $scope.updateBtn = true;
        $scope.sendBtn = false;         
    }

    $scope.updateComment = function(){
        var i = $scope.index;
        var postCommentId = $scope.commentId;
        var loginUserInfo = storageService.get('userDetails');
        loginUserInfo = JSON.parse(loginUserInfo);
        var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
        var comment = $scope.userComment['comment'];
        
        var params = {postCommentId : postCommentId, postId:postId, userObj:JSON.stringify(userObj), comment : comment};
        commentsService.updateComment(params).then(function(resp){
            if(resp.data.success == true){
                angular.forEach($scope.allCommentsData, function(values, key) {
                    if(i == key){
                        $scope.allCommentsData[i].comment = comment;
                    } else{
                        return false;
                    }                
                });

            } else{
                return false;
            }
            
            $scope.updateBtn = false;
            $scope.sendBtn = true;
            $scope.userComment.comment = "";
            $scope.getAllComments();

        }, function(error){
            commonService.showAlert("Error", error)
        });
    }

    $scope.deleteComment = function(commentId){
        var params = {postId:postId, postCommentId : commentId};
        commentsService.deleteComment(params).then(function(resp){
            $scope.getAllComments();

        }, function(error){
            commonService.showAlert("Error", error)
        });
    }

    $scope.myGoBack = function() {
        $ionicHistory.goBack();
    };

    
    $scope.getAllComments();
});


