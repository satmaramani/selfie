starterModule.controller('setupCtrl', function($scope, $rootScope,$state,userService,storageService,authService) {

	function validateToken(token){
		authService.validateUserToken({token : token}).then(function(res){
			if(res.data.success){
				getUserDetails();
			}else{
				$state.go('app.signIn');
			}
		},function(err){
			$state.go('app.signIn');
		})
	}

	function getUserDetails(){
		var userId = storageService.get('userId');
		if(userId){
				userService.getUserDeatails({userId:userId}).success(function(res){
		            if(res.success){
		            	userService._USER = res.user;	
		            	$state.go('app.home');        
		            }else{
						$state.go('app.signIn');        
		            }
		            
		        })
		        .error(function(){
		    		$state.go('app.signIn');        
		        });
		}else{
			$state.go('app.signIn');
		}
		
	}

	//this function gets token from DB and validate against Server
	//if token is invalid, redirect to login
	//if token is valid, make getUserDetails Call save data to service and goto home page
	function init(){
		var token = storageService.get('token');
		if(token){
			validateToken(token);
		}else{
			$state.go('app.signIn');
		}
	}

	init();
	$rootScope.$on('refresh',function(){
		init();
	})
});