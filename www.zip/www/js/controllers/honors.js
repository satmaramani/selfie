starterModule.controller('honors', function ($scope) {
    $scope.images = [];
 
    $scope.loadImages = function() {
        for(var i = 0; i < 27; i++) {
            $scope.images.push({id: i, src: "img/bg2.jpg"});
        }
    }
})


