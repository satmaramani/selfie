starterModule.controller('friendSearchResultCtrl', function($scope,$state,$rootScope,$timeout,commonService,userService,storageService) {
    
        // Search user list
        $scope.user=$state.params.searchForUser;
        var userId=storageService.get("userId");
        if($scope.user!==null && userId.length){
            var name=$scope.user.name;
            var location=$scope.user.location;
            if($scope.user.location===""){
                location="null";
                // null is default value for location,
            }
            commonService.showLoading();
            userService.findByNameAndLocaion({name:name,location:location,userId:userId}).success(function(res){
                commonService.hideLoading();
                if(res.success){
                    $timeout(function(){
                        angular.forEach(res.data,function(obj,index){
                            if(obj.profile_photo){
                                res.data[index].profile_photo=profilePhotoBasePath+res.data[index].profile_photo;
//                                console.log(obj.profile_photo);
                            }
                            else{
                                if(obj.gender==="M")
                                    res.data[index].profile_photo="img/m_no_image.png";
                                else if(obj.gender==="F")
                                    res.data[index].profile_photo="img/f_no_image.png";
                                else
                                    res.data[index].profile_photo="img/noimage.png";
                            }
                            
                        });
                        $scope.userResult=res.data;
//                        console.log($scope.userResult);
                    });
                }
                else{
                    if(res.message=="Failed to authenticate token."){
//                        commonService.showAlert("Authenticate Failed",res.message);
                        storageService.clear();
                        $state.go("app.signIn");
                    }
                    else{
                        commonService.showAlert("Oops","Friend not found");
                        $state.go("app.home");
                    }
                }
            }).error(function(){
                storageService.clear();
                commonService.hideLoading();
                $state.go("app.signIn");
            });
        }
        else{
            $state.go("app.home");
            // Invalid search msg
        }
    
    $scope.goToUserProfile = function(user){
//        console.log(user)
        $state.go("app.friendProfile",{selectedUser:user});
        
    };
    
});