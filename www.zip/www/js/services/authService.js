starterModule.factory('authService', ['$http',function($http){
      
    var root = {};
   
    root.validateUserToken = function(params){
        return $http.post(baseUrl+"validateUserToken", params);
    };

    
    return root;
}]);