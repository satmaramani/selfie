starterModule.factory('commonService', ['$http','$ionicPopup','$ionicLoading',function($http,$ionicPopup,$ionicLoading){
      
    var root = {};
   
   root.showAlert = function(title,template) {
        var alertPopup = $ionicPopup.alert({
           title: title,
           template: template
        });
        alertPopup.then(function(res) {});
    };
   
   root.serverError = function() {
        root.hideLoading();
        root.showAlert("Server Error","Server not responding !");
    };
   
   root.showLoading = function() {
        $ionicLoading.show({
            template: 'Loading...'
        });
   };
  
    root.hideLoading = function(){
      $ionicLoading.hide();
    };

    root.sortObject = function(o) {
    return Object.keys(o).sort().reduce((r, k) => (r[k] = o[k], r), {});
}

   
    return root;
}]);