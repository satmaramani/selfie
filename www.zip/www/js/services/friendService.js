starterModule.factory('friendService', ['$http',function($http){
	var root = {};
    
    root.getFriendDeatails = function(params){
        return $http.post(baseUrl+"users/getFriendList", params);
    };

    return root;

}]);