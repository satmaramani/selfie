starterModule.controller('userProfile', function($scope, $window, $rootScope, $ionicModal,$ionicPopup,$state,$timeout,Upload,userService,storageService,commonService) {

    $scope.friend = true;

    $scope.showFolder = false;
    $scope.status = true;
    $scope.editStatus1 = true;
    $rootScope.enterLocationDetails = true;

    $scope.editStatus = function() {
        $scope.status = false;
        $scope.statusinput = true;
        $scope.editStatus1 = false;
        $scope.saveStatus1 = true;
    };

    $scope.saveStatus = function() {
        $scope.status = true;
        $scope.statusinput = false;
        $scope.editStatus1 = true;
        $scope.saveStatus1 = false;
        if($scope.userProfile.original_display_status.trim()!==$scope.userProfile.display_status.trim()){
            $scope.setUserDetails();
        }
    };

    $scope.myGoBack = function() {
        window.history.back();
    };
    
    $ionicModal.fromTemplateUrl('templates/sharePopup.html', {
        scope: $scope
    }).then(function (share) {
        $rootScope.share = share;
    });
    $rootScope.sharePopup = function () {
        $rootScope.share_popup = true;
        $ionicScrollDelegate.scrollTop();
        $rootScope.share.show();
    };
    $scope.showLoading = function() {
        commonService.showLoading();
   };
   
    $scope.getUserDetails = function(){
        $scope.userProfile={};
        var userId = storageService.get('userId');
        if(userId=="" || userId==null){
            $rootScope.profileHeader = $rootScope.myfooter = false;
            storageService.clear();
//            commonService.showAlert("User not found","Login again");
            $state.go('app.signIn');
        }
        if(!userService._USER.length){
            commonService.showLoading();
            userService.getUserDeatails({userId:userId}).success(function(res){
                commonService.hideLoading();
                if(res.success){
                    storageService.set('userDetails',JSON.stringify(res.user));
                    if(res.user.profile_photo !== ""){
                        $scope.profile_photo_view=profilePhotoBasePath+res.user.profile_photo;
                    }
                    else{
                        if(res.user.gender==="M")
                            $scope.profile_photo_view="img/m_no_image.png";
                        else if(res.user.gender==="F")
                            $scope.profile_photo_view="img/f_no_image.png";
                        else
                            $scope.profile_photo_view="img/noimage.png";
                    }
                    userService._USER = res.user;	
                    $scope.userProfile= userService._USER;
                    $scope.friendCount = $scope.userProfile.friend_ids.length;
                    $scope.userProfile.original_display_status=res.user.display_status;
                    $scope.userProfile.original_city=res.user.city;
                }
                else{
                    $rootScope.profileHeader = false;
                    storageService.clear();
//                    commonService.showAlert("Failed","User not found !");
                    $state.go('app.signIn');
                }
            })
            .error(function(){
                commonService.serverError();
            });
        }
        else{
            $scope.userProfile= userService._USER;
            $scope.userProfile.original_display_status=userService._USER.display_status;
            $scope.userProfile.original_city=userService._USER.city;            
        }
    };

    $rootScope.getLocationDetails = function(){
        
        $timeout(function(){
            var locationDetailsObj=storageService.get("placeDetails");
        
            if($scope.userProfile.city!=="")
            if(locationDetailsObj!=null && locationDetailsObj!=""){
                locationDetailsObj=JSON.parse(locationDetailsObj);
                var locDtlLen=locationDetailsObj.length;
                if(locDtlLen==1)
                   return; // not valid city
                else if(locDtlLen==2){
                    $scope.userProfile.country  = locationDetailsObj[1].value;
                    $scope.userProfile.state    = locationDetailsObj[0].value;
                    $scope.userProfile.city     = locationDetailsObj[0].value;
                }
                else if(locDtlLen==3){
                    $scope.userProfile.country  = locationDetailsObj[--locDtlLen].value;
                    $scope.userProfile.state    = locationDetailsObj[--locDtlLen].value;
                    $scope.userProfile.city     = locationDetailsObj[--locDtlLen].value;
                }   
                else{
                    $scope.userProfile.country  = locationDetailsObj[--locDtlLen].value;
                    $scope.userProfile.state    = locationDetailsObj[--locDtlLen].value;
                    var city=(locationDetailsObj[0].value).split(" ");
                    if(city[0].trim()===locationDetailsObj[locDtlLen-1].value.trim()){
                        $scope.userProfile.city     =city[0];
                    }
                    else{
                        $scope.userProfile.city     =city[0]+" "+locationDetailsObj[--locDtlLen].value;
                    }
                }
            }
        },1000);

      
    };

    $scope.profile={uploadme:"",profile_photo:"",addNewCategoryName:""}; 

    $('#container').on( "click", '#checkBtn', function(e){
        $('#submitBtn').trigger(e);
    });

    // Purpose: update user profile photo and details
    $scope.setUserDetails = function(){
        // update user profile photo if changed
        if($scope.profile.uploadme){
            Upload.upload({
                url: baseUrl+'uploadProfileImage', //webAPI exposed to upload the file
                data:{file:$scope.profile.uploadme,user_id:$scope.userProfile._id.trim()} //pass file as data, should be user ng-model
            }).then(function (resp) { //upload function returns a promise
            
            if(resp.data.success){ //validate success
                $scope.profile.profile_photo = resp.data.image;
            } 
                uploadUser();
            }, function (resp) { //catch error
               commonService.showAlert("Profile Photo Upload Failded","Please try later");
            }, function (evt) { 
//            console.log(evt);
            });
            
        }
        else{
            // update user profile details only
            uploadUser();
        } 
    };

    // Purpose: update user profile
    
    function uploadUser(){

        var params={
                    user_name:          $scope.userProfile.user_name.trim(),
                    first_name:         $scope.userProfile.first_name.trim(),
                    last_name:          $scope.userProfile.last_name.trim(),
                    email_id:           $scope.userProfile.email_id.trim(),
                    mobile_no:          $scope.userProfile.mobile_no.trim(),
                    address:            $scope.userProfile.address.trim(),
                    country:            $scope.userProfile.country.trim(),
                    state:              $scope.userProfile.state.trim(),
                    city:               $scope.userProfile.city.trim(),
                    user_id:            $scope.userProfile._id.trim(),
                    display_status:     $scope.userProfile.display_status.trim(),
                    categories:         JSON.stringify($scope.userProfile.categories)
            };
          
        if($scope.profile.profile_photo.length){
            params.profile_photo=$scope.profile.profile_photo;
        }
        
        commonService.showLoading();
        userService.setUserDetails(params).success(function(resp){
           commonService.hideLoading();
            if(resp.success){
                storageService.set('userDetails',JSON.stringify(resp.res));
                commonService.showAlert("Success","User updated successfully !");                    
                $timeout(function(){
                    $scope.userProfile=resp.res;
                });
            }
            else{
                $rootScope.profileHeader = false;
                storageService.clear();
                commonService.showAlert("Failed","Unable to update  !");
                $state.go('app.signIn');
            }
        })
        .error(function(){
            commonService.serverError();
        });
    };
    
    $scope.goToCatDetails = function(selectedCat,selectedCatName){
       $state.go("app.folder",{selectedCat:selectedCat,selectedCatName:selectedCatName});
    };
    
    // Open category popup and add new cateogry name    
    $scope.openAddCategoryPopup = function(){
        $scope.profile.addNewCategoryName="";
        var addCategoryPopup = $ionicPopup.show({
           template:'<input type="text" ng-model="profile.addNewCategoryName" placeholder="Enter Category Name Here" maxlength="20"/>',
           title:   'Add New Category Name',
           scope:   $scope,
           buttons: [
                        { 
                            text: 'Back',
                            type: 'button-assertive',
                           onTap: function(e){
                                    $scope.profile.addNewCategoryName="";
                                    addCategoryPopup.close();
                                }
                        },
                        {
                            text: 'Add',
                            type: 'button-positive',
                           onTap: function(e){
                                    if($scope.profile.addNewCategoryName){
                                        addCategory();
                                        try{
                                            show();
                                        }
                                        catch(e){}
                                    }
                                    else{
                                        commonService.showAlert("Invalid Name","Please Enter Category Name");
                                    }
                                }
                        }
           ]
        });
    };
    
    // Add category to users collection
    var addCategory = function(){
        commonService.showLoading();
        var lastCategoryKey="cat0";
        if($scope.userProfile.categories){
            $scope.userProfile.categories=commonService.sortObject($scope.userProfile.categories);
            angular.forEach($scope.userProfile.categories, function(value , key) {
                lastCategoryKey=key;
            });
        }
        var newCategoryKey="cat"+(parseInt(lastCategoryKey.replace( /[^\d.]/g, '' ))+1);
        try{
            $scope.userProfile.categories[newCategoryKey]=$scope.profile.addNewCategoryName;
        }
        catch(e){
            $scope.userProfile.categories={};
            $scope.userProfile.categories[newCategoryKey]=$scope.profile.addNewCategoryName;
        }
        return uploadUser();
        
    };
    
    $scope.getUserDetails();
    
});