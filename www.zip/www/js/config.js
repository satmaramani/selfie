
//    if(window.location.host=="ca_dairy" && false)
//    {
        var baseUrl="http://localhost:8080/api/";
//        var baseUrl="http://localhost/extra_work/loan_webservices/index.php/";
//    }
//    else
//  {var baseUrl="http://ca_webservices/index.php/";}

var profilePhotoBasePath="http://localhost/selfie/selfie_only/images/profile_images/";
var categoryImageBasePath="http://localhost/selfie/selfie_only/images/category_images/";
var postPhotoBasePath="http://localhost/selfie/selfie_only/images/post_images/",

notiType={
    frnd_reqst_sent  :           "frnd_reqst_sent",
    frnd_reqst_accept:           "frnd_reqst_accept",
    new_post_uploaded:           "new_post_uploaded", 
    post_liked:                  "post_liked", 
    post_commented:              "post_commented", 
    comment_reply:               "comment_reply",
    silver_upgrade:              "silver_upgrade",
    gold_upgrade:                "gold_upgrade",
    inc_king_queen_on_post_like: "inc_king_queen_on_post_like",
};

