starterModule.controller('postGalleryCtrl', function ($scope, $window, $rootScope,$state,$timeout,$ionicPopup,commonService,userService,storageService,categoryService,Upload, postsService) {
   
    var userDetails = JSON.parse(storageService.get('userDetails'));
    console.log(userDetails);
    
    $scope.selectedCatName= userDetails.categories;

    console.log(userDetails.categories);

    $scope.category={imgObj:""};
    $scope.showSliderDiv=true;
    $scope.showCameraDiv=false;
    $scope.photoPath="";
    
    
    // Get photo from gallery
    $scope.getPhotoFromGallery = function(){
        $scope.category.imgObj="";
        $scope.showSliderDiv=false;
        $scope.showCameraDiv=false;
    };
    
    // Get photo from camera
    $scope.getPhotoFromCamera = function(){
        $scope.category.imgObj="";
        $scope.showSliderDiv=false;
        $scope.showCameraDiv=true;        
    };
    // show category slider
    $scope.resetSlider = function(){
        $scope.category.imgObj="";
        $scope.photoPath="";
        $scope.showSliderDiv=true;
        $scope.showCameraDiv=false;
    };
    
    // ========= for Categories

    //This will hide the DIV by default.
    $scope.isVisible = false;
    $scope.showCategories = function (value) {
        //If DIV is visible it will be hidden and vice versa.
        $scope.isCategary = value;
        $scope.isVisible = value == "categary";
    }

    $scope.subCategories = function (catId) {
        $state.selectedCatId = catId; 
    }


   // Insert record in category photo schema
    function addUserPhoto(params){
        console.log(params);
        if(params.catId !== undefined && params.catId !== "" && params.catId !== null){
            
            categoryService.addPhotoInCat(params).then(function(resp){
                if(resp.data.success){
                    commonService.showAlert("Success","Photo uploaded successfully.");
                    $scope.category.imgObj="";
                }
                else{
                    commonService.showAlert("Uploading Failed","Please try later");
                }
                console.log(resp)
            },function(error){
                commonService.showAlert("Failded to add photo","Please try later");
            });

        } else{
            var loginUserInfo = JSON.parse(storageService.get('userDetails'));
            var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
            var params = {"userObj" : JSON.stringify(userObj), "photo": params.image, "title":"title22", "desc":"desc22"};

             postsService.postPhoto(params).then(function(resp){
                if(resp.data.success){
                    $state.go("app.home");
                }
                else{
                    commonService.showAlert("Uploading Failed","Please try later");
                }
                console.log(resp)
            },function(error){
                commonService.showAlert("Failded to add photo","Please try later");
            });
        }
        
    }
 
    // Upload photo in category
    $rootScope.uploadPhotoInCatGally = function(){
        if($scope.isCategary == "" || $scope.isCategary == undefined){
            return commonService.showAlert("Choose Category","Please choose below category or post");
        } else if($scope.isCategary == 'categary' && ($state.selectedCatId == "" || $state.selectedCatId == undefined)){
            return commonService.showAlert("Choose Category","Please choose below sub category");
        }

        if(!$scope.category.imgObj){
            return commonService.showAlert("Choose Photo","Choose photo from camera or gallery to upload");
        }
        else{
            if($scope.isCategary == "categary"){
                var userId = storageService.get('userId');
                Upload.upload({
                    url: baseUrl + 'uploadPhotoInCategory',
                    data: {file: $scope.category.imgObj}
                }).then(function (resp) {
                    console.log("Category image upload sccess");
                        if(resp.data.success){
                            addUserPhoto({image: resp.data.image, userId: userId, catId: $state.selectedCatId});
                        }
                        else{
                            commonService.showAlert("Failded to upload", "Please try later");
                        }
                }, function (error) { //catch error
                    commonService.serverError();
                });

            } else if($scope.isCategary == "post"){
                var userId = storageService.get('userId');
                Upload.upload({
                    url: baseUrl + 'uploadPostPhoto',
                    data: {file: $scope.category.imgObj}
                }).then(function (resp) {
                    console.log("Category image upload sccess");
                        if(resp.data.success){
                            addUserPhoto({image: resp.data.image});
                        }
                        else{
                            commonService.showAlert("Failded to upload", "Please try later");
                        }
                }, function (error) { //catch error
                    commonService.serverError();
                });
            }
        }
        
    };

});


