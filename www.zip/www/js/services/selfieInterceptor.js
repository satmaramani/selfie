starterModule.factory('selfieInterceptor', function(storageService) {
  return {
    request: function(config) {
      // do something on success
      var token = storageService.get('token');
      if(token){
        config.headers['x-access-token'] = token;
      }
      return config;
    },

     // optional method
    'response': function(response) {
      return response;
    }
    
  };
});
