starterModule.factory('friendProfileService', ['$http',function($http){
      
    var root = {};
   
    root._USER = {};

    root.getOtherUserDetails = function(params){
        return   $http.get(baseUrl+"getOtherUserDetails/"+params.fromUserId +"/"+params.toUserId);
    };

    root.sendFriendRequest  = function(params){
        return   $http.post(baseUrl+"userRequestFriend", params);
    };

    root.acceptFriendRequest  = function(params){
        return   $http.put(baseUrl+"userRequestFriend/acceptFriendRequest",params);
    };

    root.rejectFriendRequest  = function(params){
        return   $http.put(baseUrl+"userRequestFriend/rejectFriendRequest",params);
    };

    root.blockFriendRequest  = function(params){
        return   $http.put(baseUrl+"userRequestFriend/blockFriendRequest",params);
    };

    return root;
}]);