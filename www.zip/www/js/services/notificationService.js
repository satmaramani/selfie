starterModule.factory('notificationService', ['$http',function($http){
      
    var root = {};
    
    root.getFreshNotification = function(userId){
    	return   $http.get(baseUrl+"notification/fresh/"+userId);
    };
    
    root.getUserFriendsNotifications = function(params){
    	return $http.get(baseUrl+"notification/friend/"+params.userId+"/"+params.page+"/"+params.limit);
    };

    root.getUserNotification = function(params){
        return $http.get(baseUrl+"notification/"+params.userId+"/"+params.page+"/"+params.limit);
    };

    root.updateNotificationAsSeen = function(params){
        return $http.put(baseUrl+"notification",params);
    };


    return root;
}]);