starterModule.controller('page', function($scope, $rootScope, storageService, Upload, commonService, pageService, $state) {
   
    $scope.page = {imgObj:"", pageTitle:"",pageDescription:""};
	var loginUserInfo = JSON.parse(storageService.get('userDetails'));

	$scope.myGoBack = function() {
        window.history.back();
    };

    $rootScope.createPageInfo = function() {
        Upload.upload({
	        url: baseUrl + 'uploadPhotoInCategory',
	        data: {file: $scope.page.imgObj}
	    }).then(function (resp) {
	    	if(resp.data.success == true){
	    		var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
	    		var params = {"userObj":JSON.stringify(userObj), "title" : $scope.page.pageTitle, "photo": resp.data.image, "desc": $scope.page.pageDescription};
	    		$scope.createNewPage(params);
	    	} else{

	    	}

	    }, function (error) { //catch error
	        commonService.serverError();
	    });

    };
	
	$rootScope.createNewPage = function() {
        Upload.upload({
	        url: baseUrl + 'uploadPhotoInCategory',
	        data: {file: $scope.page.imgObj}
	    }).then(function (resp) {
	    	if(resp.data.success == true){
	    		var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
	    		var params = {"userObj":JSON.stringify(userObj), "title" : $scope.page.pageTitle, "photo": resp.data.image, "desc": $scope.page.pageDescription};
	    		$scope.createNewPage(params);
	    	} else{
	    		commonService.showAlert("Error","Please try later");
	    	}

	    }, function (error) { //catch error
	        commonService.serverError();
	    });

    };
	
	$rootScope.updatePageInfo = function(pageId) {
        Upload.upload({
	        url: baseUrl + 'uploadPagePhoto',
	        data: {file: $scope.page.imgObj}
	    }).then(function (resp) {
	    	if(resp.data.success == true){
	    		var userObj = {"id": loginUserInfo['_id'],"first_name": loginUserInfo['first_name'],"last_name":loginUserInfo['last_name'],"profile_photo":loginUserInfo['profile_photo']};
	    		var params = {"userObj":JSON.stringify(userObj), "title" : $scope.page.pageTitle, "photo": resp.data.image, "desc": $scope.page.pageDescription, "pageId" : pageId};
	    		$scope.updatePageInfo(params);
	    	} else{

	    	}

	    }, function (error) { //catch error
	        commonService.serverError();
	    });

    };

	$scope.createNewPage = function(params){
		console.log(params);

		pageService.createNewPage(params).then(function(resp){
	        console.log(resp);
	        $scope.createNewPageData = true;
	        $scope.getAllPageDetails();
	        $state.go("app.page");

	    },function(error){
	        commonService.showAlert("Error","Please try later");
	    });
	}

	$scope.updatePageInfo = function(params){
		console.log(params);

		pageService.updatePageInfo(params).then(function(resp){
	        console.log(resp);
	        $scope.updatePageData = true;
	        $scope.getAllPageDetails();
	        $state.go("app.page");

	    },function(error){
	        commonService.showAlert("Error","Please try later");
	    });
	}

	$scope.getAllPageDetails = function(){
		pageService.getAllPageDetails().then(function(resp){
	        console.log(resp);
	        if(resp.data.success == false){

	        	$scope.createNewPageData = true;
	        	$rootScope.createPageBtn = true;
	        } else if(resp.data.pagesData.length > 0){
	        	$scope.updatePageData = true;
	        	$scope.getPageDetails = resp.data.pagesData;
	        	angular.forEach(resp.data.pagesData, function(value , key) {
	        		$rootScope.pageId = value._id;
	            });
	        	$rootScope.updatePageBtn = true;
	        } else{
	        	commonService.showAlert("Error","Please try later");
	        }

	    },function(error){
	        commonService.showAlert("Error","Please try later");
	    });
	}

 	$scope.getAllPageDetails();
});