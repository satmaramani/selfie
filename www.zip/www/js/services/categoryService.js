starterModule.factory('categoryService', ['$http',function($http){
      
    var root = {};
   
    root.addPhotoInCat = function(params){
        return   $http.post(baseUrl+"category",params);
    };
    
    root.getCategoryImages = function(params){
        return   $http.get(baseUrl+"category/"+params.userId+"/"+params.catId);
    };
    
    root.deleteCategory = function(params){
        return $http.delete(baseUrl+"category/"+params.userId+"/"+params.catId);
    };
    
    return root;
}]);