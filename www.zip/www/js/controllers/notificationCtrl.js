starterModule.controller('notificationCtrl',
    function(   $scope, $rootScope,$state,
                notificationService,storageService,commonService){

    var userId = storageService.get('userId'),
        page   = -1,
        limit  = 10;

    $scope.friends = function(){
        $scope.activefriend = "active";
        $scope.activeuser = "";
        
        
        var params = {
            userId  : userId,
            page    : page+1,
            limit   : limit
        };
        
        notificationService.getUserFriendsNotifications(params).then(function(resp){
            $scope.notificationData = resp.data.notificationData;
        });
        
    };

    $scope.users = function(){
        $scope.activefriend = "";
        $scope.activeuser = "active";
        var params = {
            userId  : userId,
            page    : page+1,
            limit   : limit
        };
        
        notificationService.getUserNotification(params).then(function(resp){
            $scope.notificationData = resp.data.notificationData;
        }, function(error){
//            commonService.serverError();
        });

        
    };
    // Get user's notification by default
    $scope.users();
     
     
    $scope.notificationAction = function(notificationDetail){
//        console.log(notificationDetail)
        if(
            notificationDetail.type === notiType.post_liked || 
            notificationDetail.type === notiType.post_commented || 
            notificationDetail.type === notiType.new_post_uploaded || 
            notificationDetail.type === notiType.inc_king_queen_on_post_like ){
        
            $state.go("app.postPhotos",{ postPhotosDetail : notificationDetail });
            
        }
        else if(
            notificationDetail.type === notiType.frnd_reqst_accept || 
            notificationDetail.type === notiType.frnd_reqst_sent ){
            $state.go("app.friendProfile",{selectedUser:{notificationDetail:notificationDetail}});
        }
        
    };
     
     
     
});