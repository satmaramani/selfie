starterModule.controller('postPhotosCtrl',
    function(   $scope, $rootScope,  $state, $ionicHistory, 
                postsService,notificationService ){


                
    if($state.params.postPhotosDetail===null || $state.params.postPhotosDetail==="")
        $ionicHistory.goBack();
    else{
        
        postsService.getPostPhotosDetail($state.params.postPhotosDetail.type_id).then(function(resp){
            if(resp.data.success){
                $scope.postPhotos = resp.data.postPhotosData;
                $scope.postPhotos.user_obj.profile_photo=profilePhotoBasePath+$scope.postPhotos.user_obj.profile_photo;
                $scope.postPhotos.photo=postPhotoBasePath+$scope.postPhotos.photo;
            }
            else
                console.log(resp);
            
        },function(error){
//           console.log("getPostPhotosDetail error");
//           console.log(error);
        });
    }
    
    $scope.goCommentsPage = function(){
       
        $state.go('app.comments', {commentParams:{
            postId  : $scope.postPhotos._id
        }});
    };    
    
    function updateNotificationAsSeen(notificationIdsArr){
        
        notificationService.updateNotificationAsSeen({notificationIds:notificationIdsArr}).then(function(resp){
            if(resp.data.success){
                if($rootScope.newNotificationCnt)
                $rootScope.newNotificationCnt-=1;
            }
        },function(error){
            
        });
    }
    
    updateNotificationAsSeen([$state.params.postPhotosDetail._id]);

});